from flask import Flask, render_template, request
import requests

app = Flask(__name__)

# Ruta de inicio (index)
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        ciudad = request.form.get("ciudad")
        if ciudad:
            # API para obtener información del clima (reemplaza 'API_KEY' con tu propia clave)
            url = f"http://api.openweathermap.org/data/2.5/weather?q={ciudad}&appid=API_KEY&units=metric&lang=es"
            respuesta = requests.get(url)
            data = respuesta.json()

            if data["cod"] == 200:
                # Si la API responde correctamente
                clima = data["weather"][0]["description"]
                temperatura = data["main"]["temp"]
                latitud = data["coord"]["lat"]
                longitud = data["coord"]["lon"]
                return render_template("index.html", clima=clima, temperatura=temperatura, latitud=latitud, longitud=longitud, ciudad=ciudad)
            else:
                # Si hay un error en la respuesta
                mensaje_error = "No se pudo obtener información para esta ciudad."
                return render_template("index.html", mensaje_error=mensaje_error)
    return render_template("index.html")

# Ruta del CV
@app.route("/cv")
def cv():
    return render_template("cv.html")

if __name__ == "__main__":
    app.run(debug=True)
